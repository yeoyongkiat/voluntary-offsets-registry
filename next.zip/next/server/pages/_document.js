var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_document.js")
R.c("server/chunks/ssr/[root-of-the-server]__440b0cfe._.js")
R.c("server/chunks/ssr/[root-of-the-server]__bbc31118._.js")
R.m(58039)
module.exports=R.m(58039).exports
