var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/projects-table/route.js")
R.c("server/chunks/[root-of-the-server]__2aacab72._.js")
R.c("server/chunks/node_modules__pnpm_2ae86667._.js")
R.c("server/chunks/node_modules__pnpm_badf0515._.js")
R.c("server/chunks/[root-of-the-server]__012d3512._.js")
R.m(16104)
R.m(75748)
module.exports=R.m(75748).exports
