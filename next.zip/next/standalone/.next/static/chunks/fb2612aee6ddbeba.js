__turbopack_load_page_chunks__("/_app", [
  "static/chunks/56591eec5fa21a5f.js",
  "static/chunks/f7b722e6136920fd.js",
  "static/chunks/turbopack-4c72dfe9fbce3089.js"
])
