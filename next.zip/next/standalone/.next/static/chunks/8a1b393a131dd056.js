__turbopack_load_page_chunks__("/_error", [
  "static/chunks/df74b0b1a257d5ac.js",
  "static/chunks/f7b722e6136920fd.js",
  "static/chunks/turbopack-35904511e9546cf5.js"
])
