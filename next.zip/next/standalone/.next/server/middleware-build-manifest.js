globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/56591eec5fa21a5f.js",
      "static/chunks/f7b722e6136920fd.js",
      "static/chunks/turbopack-4c72dfe9fbce3089.js"
    ],
    "/_error": [
      "static/chunks/df74b0b1a257d5ac.js",
      "static/chunks/f7b722e6136920fd.js",
      "static/chunks/turbopack-35904511e9546cf5.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/58a1d1f0810695ea.js",
    "static/chunks/826a144905b81467.js",
    "static/chunks/945a74b78ae59a5e.js",
    "static/chunks/106f5dd3e49c71c1.js",
    "static/chunks/turbopack-1d84ac35a0dda65a.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];